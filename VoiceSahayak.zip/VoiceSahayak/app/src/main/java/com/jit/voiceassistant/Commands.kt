package com.jit.voiceassistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings

object Commands {

    private fun normalizeDigits(s: String): String {
        val bn = "০১২৩৪৫৬৭৮৯"
        val sb = StringBuilder()
        for (c in s) {
            val i = bn.indexOf(c)
            sb.append(if (i >= 0) ('0' + i) else c)
        }
        return sb.toString()
    }

    private fun has(t: String, vararg words: String) = words.any { t.contains(it) }

    private fun removeWords(t: String, words: List<String>): String {
        return t.split(" ", "\n")
            .filter { w -> w.isNotBlank() && words.none { w == it } }
            .joinToString(" ")
            .trim()
    }

    fun handle(a: Activity, raw: String): String {
        val t = normalizeDigits(raw.lowercase().trim())
        return try {
            when {
                has(t, "ভলিউম", "volume", "আওয়াজ", "awaaz", "সাউন্ড", "sound") -> volume(a, t)
                has(t, "টর্চ", "torch", "flashlight", "ফ্ল্যাশ", "বাতি", "লাইট", "light") -> torch(a, t)
                has(t, "অ্যালার্ম", "এলার্ম", "alarm", "অ্যালারাম") -> alarm(a, t)
                has(t, "বাজাও", "bajao", "play", "গান", "song") -> playSong(a, t)
                has(t, "ফোন", "কল", "call", "phone") -> call(a, t)
                has(t, "খোল", "খুল", "ওপেন", "open", "kholo", "চালু", "চালাও") -> openApp(a, t)
                else -> "বুঝতে পারিনি: \"$raw\""
            }
        } catch (e: Exception) {
            "সমস্যা হয়েছে: ${e.message}"
        }
    }

    // ---------- টর্চ ----------
    private fun torch(a: Activity, t: String): String {
        val on = !has(t, "বন্ধ", "নিভ", "অফ", "off", "band")
        val cm = a.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "ফোনে ফ্ল্যাশ পাওয়া যায়নি"
        cm.setTorchMode(id, on)
        return if (on) "টর্চ জ্বালানো হলো" else "টর্চ বন্ধ করা হলো"
    }

    // ---------- ভলিউম ----------
    private fun volume(a: Activity, t: String): String {
        val am = a.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when {
            has(t, "বাড়", "বেশি", "আপ", "up", "তেজ", "tej", "জোরে", "zor") -> {
                repeat(3) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                }
                "ভলিউম বাড়ানো হলো"
            }
            has(t, "কম", "ডাউন", "down", "আস্তে", "ধীরে", "dheere") -> {
                repeat(3) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                }
                "ভলিউম কমানো হলো"
            }
            else -> "ভলিউম বাড়াবো না কমাবো?"
        }
    }

    // ---------- অ্যালার্ম ----------
    private fun alarm(a: Activity, t: String): String {
        val nums = Regex("\\d{1,2}").findAll(t).map { it.value.toInt() }.toList()
        if (nums.isEmpty()) return "কয়টায় অ্যালার্ম? যেমন: সকাল ৬টায় অ্যালার্ম দাও"
        var h = nums[0]
        var min = nums.getOrNull(1) ?: 0
        if (has(t, "সাড়ে")) min = 30
        if (has(t, "সোয়া")) min = 15
        if (min > 59) min = 0
        if (has(t, "বিকেল", "দুপুর", "সন্ধ্যা", "pm") && h < 12) h += 12
        if (has(t, "রাত") && h < 12 && h >= 6) h += 12
        if (has(t, "রাত") && h == 12) h = 0
        if (h > 23) return "সময়টা বুঝতে পারিনি"
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "ভয়েস সহায়ক")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        a.startActivity(i)
        return "অ্যালার্ম সেট: %02d:%02d".format(h, min)
    }

    // ---------- ইউটিউবে গান ----------
    private fun playSong(a: Activity, t: String): String {
        val stop = listOf(
            "ইউটিউবে", "ইউটিউব", "youtube", "গান", "গানটা", "বাজাও", "চালাও", "চালিয়ে",
            "দাও", "দে", "play", "bajao", "song", "এ", "একটা", "আমার"
        )
        val q = removeWords(t, stop)
        if (q.isBlank()) return "কোন গান বাজাবো?"
        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
        val i = Intent(Intent.ACTION_VIEW, uri)
        try {
            i.setPackage("com.google.android.youtube")
            a.startActivity(i)
        } catch (e: Exception) {
            i.setPackage(null)
            a.startActivity(i)
        }
        return "ইউটিউবে খোঁজা হচ্ছে: $q"
    }

    // ---------- ফোন করা ----------
    private fun call(a: Activity, t: String): String {
        val stop = listOf(
            "ফোন", "কল", "করো", "কর", "করুন", "করে", "দাও", "দে", "call", "phone", "karo", "ko", "কে", "একটা", "আমার"
        )
        val rest = removeWords(t, stop)
        val digits = rest.filter { it.isDigit() }
        val number: String
        if (digits.length >= 6) {
            number = digits
        } else {
            val name = rest.removeSuffix("কে").trim()
            if (name.isBlank()) return "কাকে ফোন করবো?"
            if (a.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                return "কনট্যাক্টের অনুমতি দাও (সেটিংস > অ্যাপ > ভয়েস সহায়ক > অনুমতি)"
            }
            number = findNumber(a, name) ?: return "\"$name\" নামে কনট্যাক্ট পাইনি"
        }
        if (a.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return "ফোন করার অনুমতি দাও (সেটিংস > অ্যাপ > ভয়েস সহায়ক > অনুমতি)"
        }
        a.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))
        return "ফোন করা হচ্ছে: $number"
    }

    private fun findNumber(a: Activity, name: String): String? {
        val c = a.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"),
            null
        ) ?: return null
        c.use {
            if (it.moveToFirst()) return it.getString(1)
        }
        return null
    }

    // ---------- অ্যাপ খোলা ----------
    private val aliases = mapOf(
        "ফেসবুক" to "com.facebook.katana",
        "facebook" to "com.facebook.katana",
        "হোয়াটসঅ্যাপ" to "com.whatsapp",
        "whatsapp" to "com.whatsapp",
        "ইউটিউব" to "com.google.android.youtube",
        "youtube" to "com.google.android.youtube",
        "ক্রোম" to "com.android.chrome",
        "chrome" to "com.android.chrome",
        "ইনস্টাগ্রাম" to "com.instagram.android",
        "instagram" to "com.instagram.android",
        "টেলিগ্রাম" to "org.telegram.messenger",
        "telegram" to "org.telegram.messenger",
        "ফোনপে" to "com.phonepe.app",
        "phonepe" to "com.phonepe.app"
    )

    private fun openApp(a: Activity, t: String): String {
        val pm = a.packageManager
        if (has(t, "সেটিংস", "settings")) {
            a.startActivity(Intent(Settings.ACTION_SETTINGS))
            return "সেটিংস খোলা হলো"
        }
        for ((key, pkg) in aliases) {
            if (t.contains(key)) {
                val li = pm.getLaunchIntentForPackage(pkg)
                if (li != null) {
                    a.startActivity(li)
                    return "খোলা হলো: $key"
                }
            }
        }
        val stop = listOf(
            "খোলো", "খুলো", "খুলে", "দাও", "ওপেন", "open", "kholo", "করো", "চালু", "চালাও", "অ্যাপ", "app", "এপ", "দে"
        )
        val q = removeWords(t, stop)
        if (q.isBlank()) return "কোন অ্যাপ খুলবো?"
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        for (ri in apps) {
            val label = ri.loadLabel(pm).toString().lowercase()
            if (label.length > 1 && (label.contains(q) || q.contains(label))) {
                val li = pm.getLaunchIntentForPackage(ri.activityInfo.packageName)
                if (li != null) {
                    a.startActivity(li)
                    return "খোলা হলো: $label"
                }
            }
        }
        return "\"$q\" নামে অ্যাপ পাইনি"
    }
}
