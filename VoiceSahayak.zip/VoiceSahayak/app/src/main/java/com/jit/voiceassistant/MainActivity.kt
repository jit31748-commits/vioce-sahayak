package com.jit.voiceassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var langBtn: Button

    private val langs = listOf("bn-BD" to "বাংলা", "hi-IN" to "हिन्दी", "en-IN" to "English")
    private var langIndex = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }

        val title = TextView(this).apply {
            text = "ভয়েস সহায়ক"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(title)

        val micBtn = Button(this).apply {
            text = "🎤  বলো"
            textSize = 24f
            setOnClickListener { listen() }
        }
        root.addView(micBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(90)
        ).apply { topMargin = dp(30) })

        langBtn = Button(this).apply {
            text = "ভাষা: ${langs[langIndex].second}"
            setOnClickListener {
                langIndex = (langIndex + 1) % langs.size
                text = "ভাষা: ${langs[langIndex].second}"
            }
        }
        root.addView(langBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })

        status = TextView(this).apply {
            text = "বাটন চেপে বলো"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, dp(6))
        }
        root.addView(status)

        result = TextView(this).apply {
            text = ""
            textSize = 18f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(result)

        val hint = TextView(this).apply {
            text = "উদাহরণ:\n" +
                "• টর্চ জ্বালাও / টর্চ বন্ধ করো\n" +
                "• ভলিউম বাড়াও / ভলিউম কমাও\n" +
                "• সকাল ৬টায় অ্যালার্ম দাও\n" +
                "• রহিমকে ফোন করো\n" +
                "• ইউটিউবে একটা গান বাজাও (গানের নাম)\n" +
                "• ফেসবুক খোলো / হোয়াটসঅ্যাপ খোলো"
            textSize = 15f
            setPadding(0, dp(30), 0, 0)
        }
        root.addView(hint)

        setContentView(root)

        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS
            ), 1
        )
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.text = "আগে মাইকের অনুমতি দাও"
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "ফোনে স্পিচ রিকগনিশন নেই (Google অ্যাপ আপডেট করো)"
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "শুনছি... বলো" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "বুঝছি..." }
            override fun onError(error: Int) {
                status.text = "শুনতে পাইনি, আবার চেষ্টা করো (কোড $error)"
            }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = list?.firstOrNull()
                if (text.isNullOrBlank()) {
                    status.text = "কিছু বুঝিনি, আবার বলো"
                    return
                }
                status.text = "তুমি বললে: $text"
                result.text = Commands.handle(this@MainActivity, text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, langs[langIndex].first)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        recognizer!!.startListening(i)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }
}
